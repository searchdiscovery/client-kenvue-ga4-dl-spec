# Select Search Result

This event has been rolled into the [select_content](/events/lists/select_content.md), [select_item](/events/lists/select_item.md), and [select_promotion](/events/promotions/select_promotion.md) events.
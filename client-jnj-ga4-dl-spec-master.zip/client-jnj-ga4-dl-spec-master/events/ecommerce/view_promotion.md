[See "View Promotion" Event](/events/promotions/view_promotion.md)

[See "Select Item" Event](/events/lists/select_item.md)

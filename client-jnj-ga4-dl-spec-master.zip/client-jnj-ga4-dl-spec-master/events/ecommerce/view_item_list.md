[See "View Item List" Event](/events/lists/view_item_list.md)

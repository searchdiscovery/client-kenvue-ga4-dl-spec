[See "Select Promotion" Event](/events/promotions/select_promotion.md)

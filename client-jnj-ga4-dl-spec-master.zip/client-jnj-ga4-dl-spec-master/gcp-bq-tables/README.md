## Google Cloud - BQ Google Analytics Datasets
|GCP Project Number|GCP Project Name|Dataset ID|GA4/UA Property Feed|GA4/UA Property ID|Data Set Type
| --- | --- | --- | --- | --- | --- |
|747533556496|jjt-consumerdatalake-bigquery|analytics_348451773|Kenvue\|Corporate\|GA4|348451773|GA4|
|747533556496|jjt-consumerdatalake-bigquery|analytics_254081717|Consumer - Global|254081717|GA4|
|747533556496|jjt-consumerdatalake-bigquery|184383534|Consumer - Global|UA-128610710-1|UA|
|747533556496|jjt-consumerdatalake-bigquery|140081701|Dr:Ci-Labo|UA-1583302-1|UA|
|1077250011785|gtm-wnd6vzj-yme0m|analytics_315851723|Consumer Heath - GA4 Test - GA4|315851723|GA4|
